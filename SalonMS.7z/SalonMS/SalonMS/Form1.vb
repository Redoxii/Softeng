﻿Imports System.Data.OleDb
Imports System.Data

Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Parent = PictureBox1
        Label2.Parent = PictureBox1
        Label2.BackColor = Color.Transparent
        Label1.BackColor = Color.Transparent
        'TODO: This line of code loads data into the 'AHANSDataSet.Usernames' table. You can move, or remove it, as needed.
        Me.UsernamesTableAdapter.Fill(Me.AHANSDataSet.Usernames)
    End Sub
    Private Sub UsernamesBindingNavigatorSaveItem_Click_2(sender As Object, e As EventArgs) Handles UsernamesBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.UsernamesBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.AHANSDataSet)

    End Sub

    Private Sub BunifuThinButton21_Click(sender As Object, e As EventArgs) Handles BunifuThinButton21.Click
        Dim username As String
        Dim password As String

        username = BunifuMaterialTextbox1.Text
        password = BunifuMaterialTextbox2.Text
        '
        If Me.UsernamesTableAdapter.ScalarQueryLogin(username, password) Then
            MetroFramework.MetroMessageBox.Show(Me, "Welcome Back!", "Log In Success", MessageBoxButtons.OK, MessageBoxIcon.Question)
            dashboard.Show()
            BunifuMaterialTextbox1.Text = ""
            BunifuMaterialTextbox2.Text = ""
            Me.Hide()
        ElseIf username = "" Then
            MetroFramework.MetroMessageBox.Show(Me, "Please Enter a Username!", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
        ElseIf password = "" Then
            MetroFramework.MetroMessageBox.Show(Me, "Please Enter a Password!", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            MetroFramework.MetroMessageBox.Show(Me, "Please Enter Correct Username and Password!", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            BunifuMaterialTextbox1.Text = ""
            BunifuMaterialTextbox2.Text = ""
        End If

    End Sub

    Private Sub BunifuThinButton22_Click(sender As Object, e As EventArgs) Handles BunifuThinButton22.Click
        'Closing the program
        Dim result = MetroFramework.MetroMessageBox.Show(Me, "Are you sure you want to exit the application?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
        If result = Windows.Forms.DialogResult.Yes Then
            Me.Close()
        End If
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click
        'Para sa hint sa "Click Here"
        MetroFramework.MetroMessageBox.Show(Me, "Favorite Dish.", "Password Hint:", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

End Class
