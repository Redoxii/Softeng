﻿Public Class dashboard



    Private Sub dashboard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'AHANSDataSet.Usernames' table. You can move, or remove it, as needed.
        Timer1.Start()
       
    End Sub

    Private Sub BunifuThinButton21_Click(sender As Object, e As EventArgs) Handles BunifuThinButton21.Click
        'Logging out 
        Dim result = MetroFramework.MetroMessageBox.Show(Me, "Are you sure you want to Logout?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
        If result = Windows.Forms.DialogResult.Yes Then
            Form1.Show()
            Me.Hide()
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        'Timer for the time and date
        Label3.Text = DateAndTime.Now.ToString("h:mm:ss tt | dd MMMM yy dddd")
    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        UserControl11.BringToFront()
    End Sub

    Private Sub BunifuFlatButton3_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton3.Click
        UserControl21.BringToFront()
    End Sub
End Class