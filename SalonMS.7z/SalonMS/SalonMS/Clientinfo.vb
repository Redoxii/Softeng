﻿Public Class Clientinfo

End Class